<link href="<?php echo e(asset('css/bootstrap/bootstrap.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/jquery/jquery-ui.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/datatables/dataTables.bootstrap5.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/datatables/responsive.bootstrap5.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/datatables/buttons.bootstrap5.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/variables.css')); ?>" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/components/styles.blade.php ENDPATH**/ ?>