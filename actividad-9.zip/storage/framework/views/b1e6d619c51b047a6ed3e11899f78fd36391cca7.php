<div class="row">
	<div class="col">
		<label for="<?php echo e($name); ?>" class="col-form-label text-lg-right text-secondary">
			<?php echo app('translator')->get('auth.'.$name); ?>
		</label>
	</div>
</div>
<div class="row mb-4">
	<div class="col">
		<input id="<?php echo e($name); ?>" type="<?php echo e($type); ?>" class="form-control input-login <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input" 
			name="<?php echo e($name); ?>" required autocomplete="<?php echo e($name); ?>" placeholder="<?php echo app('translator')->get('auth.'.$name); ?>" value="<?php echo e(old($name)); ?>">

		<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
</div><?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/auth/register-row.blade.php ENDPATH**/ ?>